# --- CONFIGURACIÓN INICIAL ---
# Ruta donde guardaste tu CSV
$csvPath = "$PSScriptRoot\usuarios.csv"

# La base de tu dominio (Ej: DC=miempresa,DC=local)
# Cambia esto por tus datos reales
$dominioBase = "DC=grupo5,DC=com" 

# Importamos los datos del CSV
$usuarios = Import-Csv -Path $csvPath

# --- BUCLE PRINCIPAL ---
foreach ($fila in $usuarios) {
    
    # 1. Definir variables para esta vuelta del bucle
    $nombre = $fila.Nombre
    $apellido = $fila.Apellido
    $usuario = $fila.SamAccountName
    $nombreOU = $fila.OUName
    $password = $fila.Password | ConvertTo-SecureString -AsPlainText -Force
    
    # Construimos el Distinguished Name (DN) de la OU
    $rutaOU = "OU=$nombreOU,$dominioBase"

    # --- LÓGICA DE LA OU ---
    try {
        # Intentamos obtener la OU para ver si existe
        $existeOU = Get-ADOrganizationalUnit -Identity $rutaOU -ErrorAction Stop
        Write-Host "La OU '$nombreOU' ya existe." -ForegroundColor Green
    }
    catch {
        # Si da error (no existe), la creamos
        Write-Host "La OU '$nombreOU' no existe. Creando..." -ForegroundColor Yellow
        New-ADOrganizationalUnit -Name $nombreOU -Path $dominioBase
    }

    # --- LÓGICA DEL USUARIO ---
    try {
        # Intentamos ver si el usuario ya existe
        $existeUser = Get-ADUser -Identity $usuario -ErrorAction Stop
        Write-Host "El usuario '$usuario' ya existe. Saltando..." -ForegroundColor DarkGray
    }
    catch {
        # Si no existe, lo creamos
        Write-Host "Creando usuario '$usuario' en '$nombreOU'..." -ForegroundColor Cyan
        
        New-ADUser -Name "$nombre $apellido" `
                   -GivenName $nombre `
                   -Surname $apellido `
                   -SamAccountName $usuario `
                   -UserPrincipalName "$usuario@miempresa.local" `
                   -Path $rutaOU `
                   -AccountPassword $password `
                   -Enabled $true `
                   -ChangePasswordAtLogon $true
        
        Write-Host "Usuario '$usuario' creado exitosamente." -ForegroundColor Green
    }
    Write-Host "----------------------------------------"
}