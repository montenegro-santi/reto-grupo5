# --- CONFIGURACIÓN AUTOMÁTICA ---
$csvPath = "$PSScriptRoot\usuarios.csv"
$dominioBase = "DC=grupo5,DC=com"
$sufijoCorreo = "@grupo5.com"

# --- CARGA DE DATOS ---
Write-Host "Iniciando automatización GRUPO 5..." -ForegroundColor Cyan
try {
    $usuarios = Import-Csv -Path $csvPath -ErrorAction Stop
}
catch {
    Write-Host "ERROR: No encuentro 'usuarios.csv'." -ForegroundColor Red; Pause; Exit
}

# --- BUCLE PRINCIPAL ---
foreach ($fila in $usuarios) {

    # 1. Variables Base
    $nombre = $fila.Nombre
    $apellido = $fila.Apellido
    $nombreOU = $fila.OUName
    $password = $fila.Password | ConvertTo-SecureString -AsPlainText -Force
    
    # 2. Generación Automática de Nombres
    # Usuario: Primera letra + Apellido (jperez)
    if ($nombre -and $apellido) {
        $inicial = $nombre.Substring(0,1)
        $usuarioGenerado = ("$inicial$apellido").ToLower()
        $upn = "$usuarioGenerado$sufijoCorreo"
    } else { continue } # Si faltan datos, saltamos

    # Grupo: "G_" + Nombre del Departamento (Ej: G_Ventas)
    $nombreGrupoAuto = "G_$nombreOU"

    # Ruta LDAP
    $rutaOU = "OU=$nombreOU,$dominioBase"

    Write-Host "------------------------------------------------"
    Write-Host "Procesando: $nombre $apellido ($nombreOU)" -ForegroundColor White

    # --- PASO A: LA OU ---
    try {
        if (-not (Get-ADOrganizationalUnit -Filter "Name -eq '$nombreOU'")) {
            Write-Host " [OU] Creando OU '$nombreOU'..." -ForegroundColor Yellow
            New-ADOrganizationalUnit -Name $nombreOU -Path $dominioBase
        }
    } catch { Write-Host " [!] Error OU: $_" -ForegroundColor Red }

    # --- PASO B: EL GRUPO DE SEGURIDAD (AUTOMÁTICO) ---
    try {
        # Buscamos si existe el grupo G_Departamento
        if (-not (Get-ADGroup -Filter "Name -eq '$nombreGrupoAuto'")) {
            Write-Host " [Grupo] Creando grupo '$nombreGrupoAuto'..." -ForegroundColor Yellow
            # Lo guardamos dentro de la misma OU del departamento
            New-ADGroup -Name $nombreGrupoAuto `
                        -GroupScope Global `
                        -GroupCategory Security `
                        -Path $rutaOU
        }
    } catch { Write-Host " [!] Error Grupo: $_" -ForegroundColor Red }

    # --- PASO C: EL USUARIO ---
    $usuarioCreado = $false
    try {
        if (-not (Get-ADUser -Filter "SamAccountName -eq '$usuarioGenerado'")) {
            Write-Host " [User] Creando usuario '$usuarioGenerado'..." -ForegroundColor Cyan
            New-ADUser -Name "$nombre $apellido" `
                       -GivenName $nombre `
                       -Surname $apellido `
                       -SamAccountName $usuarioGenerado `
                       -UserPrincipalName $upn `
                       -Path $rutaOU `
                       -AccountPassword $password `
                       -Enabled $true `
                       -ChangePasswordAtLogon $true
            $usuarioCreado = $true
        } else {
            Write-Host " [User] El usuario ya existe." -ForegroundColor DarkGray
            $usuarioCreado = $true # Marcamos true para verificar grupo
        }
    } catch { Write-Host " [!] Error Usuario: $_" -ForegroundColor Red }

    # --- PASO D: UNIR USUARIO A GRUPO ---
    if ($usuarioCreado) {
        try {
            # Comprobamos si ya es miembro para no dar error
            $miembros = Get-ADGroupMember -Identity $nombreGrupoAuto | Select-Object -ExpandProperty SamAccountName
            
            if ($miembros -contains $usuarioGenerado) {
                Write-Host " [Membresia] Ya pertenece al grupo." -ForegroundColor DarkGray
            } else {
                Add-ADGroupMember -Identity $nombreGrupoAuto -Members $usuarioGenerado
                Write-Host " [Membresia] Añadido a '$nombreGrupoAuto' EXITOSAMENTE." -ForegroundColor Green
            }
        } catch { Write-Host " [!] Error al unir al grupo: $_" -ForegroundColor Red }
    }
}
Write-Host "------------------------------------------------"
Write-Host "PROCESO FINALIZADO" -ForegroundColor Green